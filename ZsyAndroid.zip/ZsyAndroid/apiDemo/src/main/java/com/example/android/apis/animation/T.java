package com.example.android.apis.animation;

/**
 * Created by zsy on 2018/3/13.
 */

public class T {
    /*
    * AccelerateDecelerateInterpolator============动画开始与结束的地方速率改变比较慢，在中间的时候加速。
      AccelerateInterpolator===================动画开始的地方速率改变比较慢，然后开始加速。
      AnticipateInterpolator ==================开始的时候向后然后向前甩。
      AnticipateOvershootInterpolator=============开始的时候向后然后向前甩一定值后返回最后的值。
      BounceInterpolator=====================动画结束的时候弹起。
      CycleInterpolator======================动画循环播放特定的次数，速率改变沿着正弦曲线。
      DecelerateInterpolator===================在动画开始的地方快然后慢。
      LinearInterpolator======================以常量速率改变。
      OvershootInterpolator====================向前甩一定值后再回到原来位置。
      PathInterpolator========================新增的，就是可以定义路径坐标，然后可以按照路径坐标来跑动；注意其坐标并
    * */
}
