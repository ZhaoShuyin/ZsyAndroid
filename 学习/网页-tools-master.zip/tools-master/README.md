# tools
稀奇古怪的小demo
持续更新，欢迎watch和star。
---
1. ruler/刻度尺效果  

![效果图](http://upload-images.jianshu.io/upload_images/7866286-f041fba15a44d0ff.gif?imageMogr2/auto-orient/strip)  

[博客地址](http://blog.csdn.net/lichking11/article/details/78296061)  
实现一个滑动刻度尺并动态读取刻度的demo。

2. progress-bar/进度条效果  
![效果图](http://ox34ivs2j.bkt.clouddn.com/%E8%BF%9B%E5%BA%A6%E6%9D%A1.gif)

3. loading/等待动画效果  
![效果图](http://ox34ivs2j.bkt.clouddn.com/loading.gif)

4. letter-man/字母小人  
![效果图](http://ox34ivs2j.bkt.clouddn.com/letter-man.gif)